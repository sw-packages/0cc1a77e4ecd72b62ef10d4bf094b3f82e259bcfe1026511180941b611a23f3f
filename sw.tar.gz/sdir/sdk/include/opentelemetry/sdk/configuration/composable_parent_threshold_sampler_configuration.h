// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include <memory>

#include "opentelemetry/sdk/configuration/composable_sampler_configuration.h"
#include "opentelemetry/version.h"

OPENTELEMETRY_BEGIN_NAMESPACE
namespace sdk
{
namespace configuration
{

class ComposableParentThresholdSamplerConfiguration : public ComposableSamplerConfiguration
{
public:
  ComposableParentThresholdSamplerConfiguration() = default;

  // Enforce strong typing for the root pointer
  std::unique_ptr<ComposableSamplerConfiguration> root;

  void Accept(ComposableSamplerConfigurationVisitor *visitor) const override;
};

}  // namespace configuration
}  // namespace sdk
OPENTELEMETRY_END_NAMESPACE
